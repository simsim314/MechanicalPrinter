﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;

namespace GearsMathSimulator
{
    public class GearSystemDrawer
    {
        Graphics _g;
        public GearSystemDrawer(Graphics g)
        {
            _g = g;
        }


    }
}
